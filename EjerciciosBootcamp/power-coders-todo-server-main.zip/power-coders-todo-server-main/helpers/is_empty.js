const isEmpty = (obj) => Object.keys(obj).length === 0

export default isEmpty
